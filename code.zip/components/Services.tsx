
import React from 'react';
import { ServiceItem } from '../types.ts';
import { CarIcon, HomeIcon, CreditCardIcon } from './icons.tsx';

const services: ServiceItem[] = [
  {
    icon: <CarIcon className="h-10 w-10 text-blue-600 dark:text-blue-500" />,
    title: 'Predatory Auto Loans',
    description: 'Identify hidden fees, unfair interest rates, and deceptive clauses in your car loan agreement.',
  },
  {
    icon: <CreditCardIcon className="h-10 w-10 text-blue-600 dark:text-blue-500" />,
    title: 'Personal & Payday Loans',
    description: 'Uncover exploitative terms in high-interest personal loans and protect yourself from debt traps.',
  },
  {
    icon: <HomeIcon className="h-10 w-10 text-blue-600 dark:text-blue-500" />,
    title: 'Rental & Lease Agreements',
    description: 'Understand your rights and obligations, and spot unfair terms in residential or commercial leases.',
  },
];

const ServiceCard = ({ icon, title, description }: ServiceItem) => (
  <div className="bg-white dark:bg-slate-800 p-8 rounded-xl shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 border border-slate-200 dark:border-slate-700">
    <div className="mb-4">{icon}</div>
    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2" style={{fontFamily: "'Manrope', sans-serif"}}>{title}</h3>
    <p className="text-slate-600 dark:text-slate-300">{description}</p>
  </div>
);

export default function Services() {
  return (
    <section id="services" className="py-20 sm:py-24 bg-slate-100 dark:bg-slate-900/70">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white" style={{fontFamily: "'Manrope', sans-serif"}}>
            We Shine a Light on Deception
          </h2>
          <p className="mt-4 text-lg text-slate-600 dark:text-slate-300">
            Our expertise covers a wide range of consumer and commercial contracts where unfair terms often hide.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {services.map((service) => (
            <ServiceCard key={service.title} {...service} />
          ))}
        </div>
      </div>
    </section>
  );
}
