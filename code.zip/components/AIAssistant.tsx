
import React, { useState } from 'react';
import { useGemini } from '../hooks/useGemini.ts';
import { SparklesIcon } from './icons.tsx';

const GeminiResponse = ({ text }: { text: string }) => {
  const formattedHtml = text
    .replace(/^### (.*$)/gim, '<h3 class="text-xl font-bold mt-6 mb-3 text-slate-800 dark:text-slate-100" style="font-family: \'Manrope\', sans-serif;">$1</h3>')
    .replace(/^> (.*$)/gim, '<blockquote class="border-l-4 border-blue-500 pl-4 italic my-4 text-slate-600 dark:text-slate-400">$1</blockquote>')
    .replace(/^\* (.*$)/gim, '<li class="ml-5 list-disc my-1">$1</li>')
    .replace(/\n/g, '<br />')
    .replace(/<br \/>(<h3|<blockquote|<li)/gim, '$1')
    .replace(/(<\/li>)<br \/>/gim, '$1');

  return <div className="prose prose-slate dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: formattedHtml }} />;
};


export default function AIAssistant() {
  const [contractText, setContractText] = useState('');
  const { loading, error, result, analyzeContract } = useGemini();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    analyzeContract(contractText);
  };

  return (
    <section id="analyzer" className="py-20 sm:py-24 bg-slate-50 dark:bg-slate-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white" style={{fontFamily: "'Manrope', sans-serif"}}>
            Instant Contract Analysis
          </h2>
          <p className="mt-4 text-lg text-slate-600 dark:text-slate-300">
            Paste your contract text below to get an instant, AI-powered analysis identifying potential red flags and areas for negotiation.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="contract-text" className="sr-only">
                Contract Text
              </label>
              <textarea
                id="contract-text"
                name="contract-text"
                rows={12}
                className="w-full p-4 border border-slate-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-200 dark:placeholder-slate-500 transition"
                placeholder="Paste the full text of your contract here..."
                value={contractText}
                onChange={(e) => setContractText(e.target.value)}
                aria-label="Contract text input"
                disabled={loading}
              />
            </div>
            <div className="text-center">
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center gap-2 justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-slate-400 disabled:cursor-not-allowed dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-offset-slate-900 dark:disabled:bg-slate-600 transition-all transform hover:scale-105"
                aria-live="polite"
              >
                {loading ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <SparklesIcon className="h-5 w-5" />
                    Analyze with AI
                  </>
                )}
              </button>
            </div>
          </form>

          <div className="mt-12">
            {error && (
              <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md dark:bg-red-900/30 dark:text-red-300" role="alert">
                <p className="font-bold">Error</p>
                <p>{error}</p>
              </div>
            )}
            {result && (
              <div className="bg-white dark:bg-slate-800/50 p-6 sm:p-8 rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4" style={{fontFamily: "'Manrope', sans-serif"}}>Analysis Results</h3>
                <GeminiResponse text={result} />
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
