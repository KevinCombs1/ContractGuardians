
import React from 'react';
import { LogoIcon } from './icons.tsx';

export default function Footer() {
  return (
    <footer className="bg-slate-100 dark:bg-slate-900/70 border-t border-slate-200 dark:border-slate-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <a href="#" className="flex items-center gap-2" aria-label="Contract Guardians Home">
              <LogoIcon className="h-8 w-8 text-blue-600 dark:text-blue-500" />
              <span className="font-bold text-xl text-slate-800 dark:text-slate-200" style={{fontFamily: "'Manrope', sans-serif"}}>
                Contract Guardians
              </span>
            </a>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xs">
              Empowering you to understand and challenge unfair contracts with confidence.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-8">
             <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white tracking-wider uppercase">Navigate</h3>
                <ul className="mt-4 space-y-2">
                    <li><a href="#analyzer" className="text-base text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-500">AI Analyzer</a></li>
                    <li><a href="#services" className="text-base text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-500">Services</a></li>
                    <li><a href="#faq" className="text-base text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-500">FAQ</a></li>
                </ul>
             </div>
             <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white tracking-wider uppercase">Legal</h3>
                <ul className="mt-4 space-y-2">
                    <li><a href="#" className="text-base text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-500">Privacy Policy</a></li>
                    <li><a href="#" className="text-base text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-500">Terms of Service</a></li>
                </ul>
             </div>
          </div>
          <div className="bg-blue-100 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800/30">
             <h4 className="font-semibold text-blue-800 dark:text-blue-300">Important Disclaimer</h4>
             <p className="mt-2 text-sm text-blue-700 dark:text-blue-400">
                Contract Guardians is not a law firm and does not provide legal advice. Our services and AI tools are for educational purposes only. For legal advice, please consult with a qualified attorney.
             </p>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-slate-200 dark:border-slate-800 text-center text-sm text-slate-500 dark:text-slate-400">
          <p>&copy; {new Date().getFullYear()} Contract Guardians. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
