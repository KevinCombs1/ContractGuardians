
import React from 'react';
import { LogoIcon } from './icons.tsx';

export default function Header() {
  const navLinks = [
    { name: 'AI Analyzer', href: '#analyzer' },
    { name: 'Services', href: '#services' },
    { name: 'FAQ', href: '#faq' },
  ];

  return (
    <header className="bg-slate-50/80 dark:bg-slate-900/80 backdrop-blur-sm sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <a href="#" className="flex items-center gap-2" aria-label="Contract Guardians Home">
            <LogoIcon className="h-8 w-8 text-blue-600 dark:text-blue-500" />
            <span className="font-bold text-xl text-slate-800 dark:text-slate-200" style={{fontFamily: "'Manrope', sans-serif"}}>
              Contract Guardians
            </span>
          </a>
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-500 transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>
          <div className="flex items-center">
            <a
              href="#analyzer"
              className="hidden sm:inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:ring-offset-slate-900 transition-all"
            >
              Get Free Analysis
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
