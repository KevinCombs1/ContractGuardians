
import React, { useState } from 'react';
import { FAQItem } from '../types.ts';
import { ChevronDownIcon } from './icons.tsx';

const faqData: FAQItem[] = [
  {
    question: 'Is Contract Guardians a law firm?',
    answer: 'No, Contract Guardians is not a law firm and does not provide legal advice. We are an educational platform that uses AI to identify potential issues in contracts. We partner with licensed attorneys and can refer you to one for actual legal counsel.',
  },
  {
    question: 'Is the AI analysis legally binding?',
    answer: 'Absolutely not. The AI analysis is for informational and educational purposes only. It is designed to highlight potential areas of concern based on common patterns. It is not a substitute for a review by a qualified human attorney.',
  },
  {
    question: 'How much does the AI analysis cost?',
    answer: 'Our initial AI-powered contract analysis is provided free of charge to help you get a preliminary understanding of your document. For more in-depth services or attorney referrals, costs may apply.',
  },
  {
    question: 'Is my data secure?',
    answer: 'Yes. We take your privacy and data security seriously. The contract text you submit is processed securely and is not stored long-term or used for any purpose other than providing your analysis. We do not share your data with third parties without your explicit consent.',
  },
];

const AccordionItem = ({ item }: { item: FAQItem }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-slate-200 dark:border-slate-700">
      <h3>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex justify-between items-center w-full py-5 text-left text-lg font-medium text-slate-800 dark:text-slate-200"
          aria-expanded={isOpen}
          aria-controls={`faq-panel-${item.question.replace(/\s/g, '-')}`}
        >
          <span>{item.question}</span>
          <ChevronDownIcon
            className={`w-5 h-5 transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
          />
        </button>
      </h3>
      <div
        id={`faq-panel-${item.question.replace(/\s/g, '-')}`}
        className={`grid transition-all duration-300 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
      >
        <div className="overflow-hidden">
            <p className="pb-5 text-slate-600 dark:text-slate-300">
                {item.answer}
            </p>
        </div>
      </div>
    </div>
  );
};

export default function FAQ() {
  return (
    <section id="faq" className="py-20 sm:py-24 bg-slate-50 dark:bg-slate-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white" style={{fontFamily: "'Manrope', sans-serif"}}>
            Frequently Asked Questions
          </h2>
          <p className="mt-4 text-lg text-slate-600 dark:text-slate-300">
            Have questions? We have answers. Here are some of the most common inquiries we receive.
          </p>
        </div>
        <div className="max-w-3xl mx-auto">
          {faqData.map((item, index) => (
            <AccordionItem key={index} item={item} />
          ))}
        </div>
      </div>
    </section>
  );
}
