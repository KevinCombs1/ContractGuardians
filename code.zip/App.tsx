
import React from 'react';
import Header from './components/Header.tsx';
import Hero from './components/Hero.tsx';
import AIAssistant from './components/AIAssistant.tsx';
import Services from './components/Services.tsx';
import FAQ from './components/FAQ.tsx';
import Footer from './components/Footer.tsx';

export default function App() {
  return (
    <div className="bg-slate-50 dark:bg-slate-900 min-h-screen">
      <Header />
      <main>
        <Hero />
        <AIAssistant />
        <Services />
        <FAQ />
      </main>
      <Footer />
    </div>
  );
}
