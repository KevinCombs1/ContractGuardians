
export interface FAQItem {
  question: string;
  answer: string;
}

export interface ServiceItem {
  icon: React.ReactNode;
  title: string;
  description: string;
}
