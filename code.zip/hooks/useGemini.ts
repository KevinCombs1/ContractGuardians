
import { useState, useCallback } from 'react';
import { GoogleGenAI } from '@google/genai';

const API_KEY = process.env.API_KEY;

export const useGemini = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);

  const analyzeContract = useCallback(async (contractText: string) => {
    if (!API_KEY) {
      setError("API key is not configured. Please contact support.");
      return;
    }
    if (!contractText.trim()) {
      setError("Please enter some contract text to analyze.");
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const ai = new GoogleGenAI({ apiKey: API_KEY, vertexai: true });
      const systemInstruction = `You are an AI legal assistant for 'Contract Guardians'. Your purpose is to analyze user-submitted contract text to identify potentially unfair, predatory, or ambiguous clauses based on general consumer protection principles.

IMPORTANT: You must not provide legal advice. Your analysis is for educational purposes only.

Start your response with this exact disclaimer, enclosed in a markdown blockquote:
> **Disclaimer:** I am an AI assistant and not a substitute for a qualified attorney. This analysis is for educational purposes only and does not constitute legal advice. Please consult with a legal professional for guidance on your specific situation.

Then, structure your output into the following sections using markdown headings:

### Potential Red Flags
List specific clauses or phrases from the contract that could be problematic. For each, briefly explain in simple terms why it's a potential red flag (e.g., "This 'auto-renewal' clause can trap you in a service you no longer want."). Use bullet points for each flag.

### Areas for Negotiation
Suggest general topics or terms the user might want to discuss or renegotiate with the other party. Frame these as questions or points for clarification (e.g., "Consider asking for clarification on the 'early termination fee' and if it can be waived under certain circumstances."). Use bullet points.

### General Recommendations
Provide 2-3 actionable, educational tips for handling contracts like this. For example, "Always keep a signed copy of the contract for your records." or "Never feel pressured to sign immediately. Take time to review it carefully." Use bullet points.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            role: 'user',
            parts: [{ text: `Please analyze the following contract text: \n\n---\n\n${contractText}` }]
        },
        config: {
            systemInstruction: systemInstruction,
        }
      });

      const text = response.text;
      setResult(text);

    } catch (e) {
      console.error(e);
      if (e instanceof Error) {
        setError(`An error occurred: ${e.message}. Please try again later.`);
      } else {
        setError("An unknown error occurred while analyzing the contract. Please try again later.");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  return { loading, error, result, analyzeContract };
};
